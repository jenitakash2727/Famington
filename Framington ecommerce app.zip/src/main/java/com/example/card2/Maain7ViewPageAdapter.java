package com.example.card2;

import android.view.View;


import androidx.viewpager.widget.PagerAdapter;

public class Maain7ViewPageAdapter extends PagerAdapter {
    @Override
    public int getCount() {
        return 0;
    }

    @Override
    public boolean isViewFromObject( View view,  Object object) {
        return false;
    }
}
